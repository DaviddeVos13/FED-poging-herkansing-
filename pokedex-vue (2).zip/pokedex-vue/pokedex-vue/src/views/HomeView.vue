<script setup>
import TheWelcome from '../components/title.vue'
</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
